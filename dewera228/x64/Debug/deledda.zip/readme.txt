Deledda font family is distributed under a Creative Commons license.
The only condition for the free use of the font is the attribution 
of an author Dimitri Antonov / Blue Curve Designstudio in any form.

Шрифт Deledda распространяется по лицензии Creative Commons.
Единственное условие бесплатного использования шрифта — это указание 
автора Дмитрия Антонова / Синяя Кривая Студия Дизайна в любой форме.

https://www.behance.net/ed67b3fc
https://www.bluecurve.ru
https://vk.com/public211353617

